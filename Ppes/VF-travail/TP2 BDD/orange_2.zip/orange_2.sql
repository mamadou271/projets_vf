-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 10 Octobre 2024 à 15:51
-- Version du serveur :  5.6.15-log
-- Version de PHP :  5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `orange_2`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `Client_ID` int(100) NOT NULL,
  `RaisonSociale` varchar(100) NOT NULL,
  `CodePostale` varchar(100) NOT NULL,
  `Ville` varchar(100) NOT NULL,
  `Pays_ID` int(100) NOT NULL,
  `Mail` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Client_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`Client_ID`, `RaisonSociale`, `CodePostale`, `Ville`, `Pays_ID`, `Mail`) VALUES
(1, 'LVMH', '75000', 'Paris', 1, 'lwmh@entreprise.com'),
(2, 'L''OREAL', '92117', 'Clichy', 1, 'oreal@entreprise.com'),
(3, 'AIRBUS GROUP', '31700', 'Blagnac', 1, 'airbus@entreprise.com'),
(4, 'THALES', '92190', 'Meudon', 1, NULL),
(5, 'LUFTHANSA', '50441', 'Cologne', 3, NULL),
(6, 'UBISOFT Londres', 'CV324JG', 'Londres', 4, 'ubisoft@entreprise.com');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE IF NOT EXISTS `commande` (
  `Com_Num` varchar(100) NOT NULL,
  `Date_Com` date NOT NULL,
  `Client_ID` int(100) NOT NULL,
  `Devis_ID` int(100) NOT NULL,
  PRIMARY KEY (`Com_Num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `commande`
--

INSERT INTO `commande` (`Com_Num`, `Date_Com`, `Client_ID`, `Devis_ID`) VALUES
('23GT456', '2023-12-19', 2, 23679),
('23HJ345', '2023-10-06', 6, 23578),
('24AC467', '2024-06-06', 6, 24345),
('24BR987', '2024-05-21', 1, 24987);

-- --------------------------------------------------------

--
-- Structure de la table `devis`
--

CREATE TABLE IF NOT EXISTS `devis` (
  `Devis_Num` int(100) NOT NULL,
  `Date_Dev` date NOT NULL,
  `Statut` varchar(100) NOT NULL,
  `Client_ID` int(100) NOT NULL,
  `Montant` decimal(65,0) NOT NULL,
  `ITC_ID` int(100) NOT NULL,
  PRIMARY KEY (`Devis_Num`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `devis`
--

INSERT INTO `devis` (`Devis_Num`, `Date_Dev`, `Statut`, `Client_ID`, `Montant`, `ITC_ID`) VALUES
(23679, '2023-12-08', 'Transformé', 2, '34688', 0),
(24987, '2024-09-05', 'En cours', 1, '457', 0),
(24943, '2024-08-29', 'Négociation', 2, '343', 0),
(24765, '2024-05-22', 'Transformé', 5, '3488', 0),
(23578, '2023-09-28', 'Transformé', 6, '7893', 0),
(24935, '2024-09-02', 'En cours', 4, '87654', 0),
(24345, '2024-06-06', 'Transformé', 6, '9824', 0),
(24876, '2024-05-14', 'En cours', 4, '833', 0);

-- --------------------------------------------------------

--
-- Structure de la table `itc`
--

CREATE TABLE IF NOT EXISTS `itc` (
  `ITC_ID` int(100) NOT NULL,
  `Prenom` varchar(100) NOT NULL,
  `Nom` varchar(100) NOT NULL,
  `Service_ID` int(100) NOT NULL,
  PRIMARY KEY (`ITC_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `pays`
--

CREATE TABLE IF NOT EXISTS `pays` (
  `Pays_ID` int(100) NOT NULL,
  `Nom` varchar(100) NOT NULL,
  `Nom_Court` varchar(100) NOT NULL,
  PRIMARY KEY (`Pays_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `pays`
--

INSERT INTO `pays` (`Pays_ID`, `Nom`, `Nom_Court`) VALUES
(1, 'France', 'FRA'),
(2, 'Canada', 'CAN'),
(3, 'Allemagne', 'DEU'),
(4, 'Royaume-Unis', 'GBR');

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

CREATE TABLE IF NOT EXISTS `service` (
  `Service_ID` int(11) NOT NULL,
  `Nom` int(11) NOT NULL,
  `Etage` int(11) NOT NULL,
  PRIMARY KEY (`Service_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
